#include "utility.h"

#define MAXRGB 255
#define MINRGB 0

std::string utility::intToString(int number)
{
   std::stringstream ss;//create a stringstream
   ss << number;//add number to the stream
   return ss.str();//return a string with the contents of the stream
}

int utility::checkValue(int value)
{
	if (value > MAXRGB)
		return MAXRGB;
	if (value < MINRGB)
		return MINRGB;
	return value;
}


void utility::decreaseIntesity(image &src, image &tgt, int threshold, int stepValue,ROI roi)
{

	tgt.resize(src.getNumberOfRows(), src.getNumberOfColumns());
	tgt=src;

	int rowLength = roi.x1 + roi.Sx1;
	int colLength = roi.y1 + roi.Sy1;

	if(rowLength>src.getNumberOfRows())
	{
		printf("Out of bound Region of Interest");
		return;
	}

	if(colLength>src.getNumberOfColumns())
	{
		printf("Out of bound Region of Interest");
		return;
	}
	for (int i=roi.x1; i<rowLength; i++)
	{
		for (int j=roi.y1;j<colLength; j++)
		{

			int pixel = src.getPixel(i,j);

			if(pixel < threshold)
			{
				pixel=pixel-stepValue;
			}

			//check value makes sure that the pixel value is in range of max and min
			tgt.setPixel(i,j,checkValue(pixel)); 
		}

	}

}

/*-----------------------------------------------------------------------**/
void utility::addGrey(image &src, image &tgt, int value,ROI roi)
{

	tgt.resize(src.getNumberOfRows(), src.getNumberOfColumns());
	tgt=src;

	int rowLength = roi.x1 + roi.Sx1;
	int colLength = roi.y1 + roi.Sy1;

	if(rowLength>src.getNumberOfRows())
	{
		printf("Out of bound Region of Interest");
		return;
	}

	if(colLength>src.getNumberOfColumns())
	{
		printf("Out of bound Region of Interest");
		return;
	}

	for (int i=roi.x1; i<rowLength; i++)
	{
		for (int j=roi.y1;j<colLength; j++)
		{
			//check value makes sure that the pixel value is in range of max and min
			tgt.setPixel(i,j,checkValue(src.getPixel(i,j)+value));
		}
	}

}

//Rotations
//M rows
//N columns
//(j,N−1−i)
//(M−1−j,i)

image utility::rotateCCW90(image src)
{
	image tgt;
	tgt.resize(src.getNumberOfRows(), src.getNumberOfColumns());

    //transpose and reverse
	for (size_t i = 0; i < src.getNumberOfRows(); i++)
	{
		for (size_t j = 0; j < src.getNumberOfColumns(); j++)
		{
			tgt.setPixel(i,j,checkValue(src.getPixel(j,src.getNumberOfColumns()-1-i)));
		}
		
	}
	return tgt;
}

image utility::rotateCCW90Color(image src)
{
	image tgt;
	tgt.resize(src.getNumberOfRows(), src.getNumberOfColumns());

    //transpose and reverse
	for (size_t i = 0; i < src.getNumberOfRows(); i++)
	{
		for (size_t j = 0; j < src.getNumberOfColumns(); j++)
		{
			tgt.setPixel(i,j,RED,checkValue(src.getPixel(j,src.getNumberOfColumns()-1-i,RED)));
			tgt.setPixel(i,j,GREEN,checkValue(src.getPixel(j,src.getNumberOfColumns()-1-i,GREEN)));
			tgt.setPixel(i,j,BLUE,checkValue(src.getPixel(j,src.getNumberOfColumns()-1-i,BLUE)));

		}
		
	}
	return tgt;
}

image utility::mulColor(image src,float mul)
{
	image tgt;
	tgt.resize(src.getNumberOfRows(), src.getNumberOfColumns());

    //transpose and reverse
	for (size_t i = 0; i < src.getNumberOfRows(); i++)
	{
		for (size_t j = 0; j < src.getNumberOfColumns(); j++)
		{
			tgt.setPixel(i,j,RED,checkValue(src.getPixel(i,j,RED)*mul));
			tgt.setPixel(i,j,GREEN,checkValue(src.getPixel(i,j,GREEN)*mul));
			tgt.setPixel(i,j,BLUE,checkValue(src.getPixel(i,j,BLUE)*mul));

		}
		
	}

	//trouble shoot mul found problem to be signature of function int mul was turning 1.9 to 1
	// int r = src.getPixel(0,0,RED);
	// int g = src.getPixel(0,0,GREEN);
	// int b = src.getPixel(0,0,BLUE);

	// printf("Color Mul: %i\n",r);
	// printf("Color Mul: %i\n",g);
	// printf("Color Mul: %i\n\n",b);

	// printf("Color Mul: %f\n",r*1.9f);
	// printf("Color Mul: %f\n",g*1.9f);
	// printf("Color Mul: %f\n\n",b*1.9f);

	// printf("Color Mul: %f\n",src.getPixel(0,0,RED)*mul);
	// printf("Color Mul: %f\n",checkValue(src.getPixel(0,0,GREEN)*mul));
	// printf("Color Mul: %f\n\n",checkValue(src.getPixel(0,0,BLUE)*mul));

	// printf("Color Mul: %f\n",checkValue(src.getPixel(0,0,RED)));
	// printf("Color Mul: %f\n",checkValue(src.getPixel(0,0,GREEN)));
	// printf("Color Mul: %f\n",checkValue(src.getPixel(0,0,BLUE)));
	return tgt;
}

image utility::addColor(image src,int add)
{
	image tgt;
	tgt.resize(src.getNumberOfRows(), src.getNumberOfColumns());

    //transpose and reverse
	for (size_t i = 0; i < src.getNumberOfRows(); i++)
	{
		for (size_t j = 0; j < src.getNumberOfColumns(); j++)
		{
			tgt.setPixel(i,j,RED,checkValue(src.getPixel(i,j,RED)+add));
			tgt.setPixel(i,j,GREEN,checkValue(src.getPixel(i,j,GREEN)+add));
			tgt.setPixel(i,j,BLUE,checkValue(src.getPixel(i,j,BLUE)+add));

		}
		
	}
	return tgt;
}



image utility::cropROI(image &src, ROI roi)
{

	image tgt;
	
	//sr
	tgt.resize(roi.Sx1, roi.Sy1);

	int rowLength = roi.x1 + roi.Sx1;
	int colLength = roi.y1 + roi.Sy1;


	int roiOnlyI = 0;
	int roiOnlyJ = 0;
	for (int i=roi.x1; i<rowLength; i++)
	{
		roiOnlyJ = 0;
		for (int j=roi.y1;j<colLength; j++)
		{
			//check value makes sure that the pixel value is in range of max and min
			tgt.setPixel(roiOnlyI,roiOnlyJ,checkValue(src.getPixel(i,j)));
			roiOnlyJ++;
		}
		roiOnlyI++;
	}

	return tgt;

}


image utility::cropROIColor(image &src, ROI roi)
{

	image tgt;
	
	//sr
	tgt.resize(roi.Sx1, roi.Sy1);

	int rowLength = roi.x1 + roi.Sx1;
	int colLength = roi.y1 + roi.Sy1;


	int roiOnlyI = 0;
	int roiOnlyJ = 0;
	for (int i=roi.x1; i<rowLength; i++)
	{
		roiOnlyJ = 0;
		for (int j=roi.y1;j<colLength; j++)
		{
			//check value makes sure that the pixel value is in range of max and min
			tgt.setPixel(roiOnlyI,roiOnlyJ,RED,checkValue(src.getPixel(i,j,RED)));
			tgt.setPixel(roiOnlyI,roiOnlyJ,GREEN,checkValue(src.getPixel(i,j,GREEN)));
			tgt.setPixel(roiOnlyI,roiOnlyJ,BLUE,checkValue(src.getPixel(i,j,BLUE)));

			roiOnlyJ++;
		}
		roiOnlyI++;
	}

	return tgt;

}




/*-----------------------------------------------------------------------**/
void utility::binarize(image &src, image &tgt, int threshold,ROI roi)
{
	tgt.resize(src.getNumberOfRows(), src.getNumberOfColumns());
	tgt=src;

	int rowLength = roi.x1 + roi.Sx1;
	int colLength = roi.y1 + roi.Sy1;

	if(rowLength>src.getNumberOfRows())
	{
		printf("Out of bound Region of Interest");
		return;
	}

	if(colLength>src.getNumberOfColumns())
	{
		printf("Out of bound Region of Interest");
		return;
	}

	for (int i=roi.x1; i<rowLength; i++)
	{
		for (int j=roi.y1;j<colLength; j++)
		{
			if (src.getPixel(i,j) < threshold)
				tgt.setPixel(i,j,MINRGB);
			else
				tgt.setPixel(i,j,MAXRGB);
		}
	}
}

image utility::scale(image &src,float ratio)
{
	image tgt;

	int rows = (int)((float)src.getNumberOfRows() * ratio);
	int cols  = (int)((float)src.getNumberOfColumns() * ratio);
	tgt.resize(rows, cols);
	for (int i=0; i<rows; i++)
	{
		for (int j=0; j<cols; j++)
		{
			int i2 = (int)floor((float)i/ratio);
			int j2 = (int)floor((float)j/ratio);
			
			// Ensure we don't go out of bounds
			if (i2 >= src.getNumberOfRows() || j2 >= src.getNumberOfColumns()) {
				continue;
			}

			if (ratio > 1) {
				// Up-scaling
				tgt.setPixel(i, j, checkValue(src.getPixel(i2, j2)));
			} 
			else if (ratio < 1) {
				// Down-scaling with boundary check
				if (i2+1 < src.getNumberOfRows() && j2+1 < src.getNumberOfColumns()) {
					int value = src.getPixel(i2, j2) + src.getPixel(i2, j2 + 1) + 
							src.getPixel(i2 + 1, j2) + src.getPixel(i2 + 1, j2 + 1);
					tgt.setPixel(i, j, checkValue(value / 4));
				}
			}
		}
	}

	return tgt;
}
