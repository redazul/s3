#ifndef UTILITY_H
#define UTILITY_H

#include "../image/image.h"
#include <sstream>
#include <math.h>

struct ROI {
	int x1;
	int y1;
	int Sx1;
	int Sy1;
};

class utility
{
	public:
		utility();
		virtual ~utility();
		static std::string intToString(int number);
		static int checkValue(int value);
		static void decreaseIntesity(image &src, image &tgt, int threshold, int stepValue,ROI roi);
		static void addGrey(image &src, image &tgt, int value, ROI roi);
		static void binarize(image &src, image &tgt, int threshold,ROI roi);
		static image scale(image &src, float ratio);
		static image cropROI(image &src,ROI roi);
		static image rotateCCW90(image src);
		static image cropROIColor(image &src, ROI roi);
		static image rotateCCW90Color(image src);
		static image mulColor(image src,float mul);
		static image addColor(image src,int add);





};

#endif

