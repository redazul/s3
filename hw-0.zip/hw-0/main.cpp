#include <iostream>
#include <vector>
#include <string>
#include <opencv2/core.hpp>
#include <opencv2/opencv.hpp> 



using namespace std;
using namespace cv;


void convert_pgm(string image_name, string output_name){
    cv::Mat png_image = cv::imread(image_name, cv::IMREAD_GRAYSCALE);

    // Check if the image was loaded successfully
    if (!png_image.empty()) {
        // Save the image in PPM format
        cv::imwrite(output_name, png_image);
        std::cout << "PNG image converted to PGM successfully." << std::endl;
    } else {
        std::cout << "Failed to load the PNG image." << std::endl;
    }
}

int check_value(int value){
    return std::min(255, std::max(0, value));
}

int get_pixel(Mat src,int y,int x){
    int pixel_value = static_cast<int>(src.at<uchar>(y, x));
    // Ensure the pixel value stays within the [0, 255] range
    pixel_value = std::min(255, std::max(0, pixel_value));
    return pixel_value;
}

void set_pixel(Mat src,Mat tgt, int y,int x, int pixel_value){
    tgt.at<uchar>(y, x) = static_cast<uchar>(pixel_value);

}


void add_Grey(Mat src, Mat tgt, int pixel, string tgt_name){
    for (int y = 0; y < src.rows; ++y) {
        for (int x = 0; x < src.cols  ; ++x) {
            int pixel_value = static_cast<int>(src.at<uchar>(y, x)) + pixel;
            // Ensure the pixel value stays within the [0, 255] range
            pixel_value = std::min(255, std::max(0, pixel_value));
            // tgt.at<uchar>(y, x) = static_cast<uchar>(pixel_value);
            set_pixel(src,tgt,y,x,pixel_value);
        }
    }

} 

void binarize_Grey(Mat src, Mat tgt, int pixel){
    for (int y = 0; y < src.rows; ++y) {
        for (int x = 0; x < src.cols  ; ++x) {
            int pixel_value = static_cast<int>(src.at<uchar>(y, x));
            // Ensure the pixel value stays within the [0, 255] range
            if(pixel_value > pixel){
                tgt.at<uchar>(y, x) = static_cast<uchar>(255);
            }
            else{
                tgt.at<uchar>(y, x) = static_cast<uchar>(0);
            }
        }
    }
} 



void scale_Grey(Mat src, Mat tgt, float ratio){
    for (int i=0; i<tgt.rows; ++i)
	{
		for (int j=0; j<tgt.cols; ++j)
		{	
			/* Map the pixel of new image back to original image */
			int i2 = (int)floor((float)i/ratio);
			int j2 = (int)floor((float)j/ratio);
			if (ratio == 2.0) {
                set_pixel(src, tgt, i,j, get_pixel(src,i2,j2));
			}

			if (ratio == 0.5) {
				/* Average the values of four pixels */
                int value = get_pixel(src,i2,j2) + get_pixel(src,i2,j2+1) + get_pixel(src,i2+1,j2) + get_pixel(src,i2+1,j2+1);
                set_pixel(src, tgt, i, j, check_value(value/4));
			}
		}
	}
}
 

void save_image(Mat tgt, string output_name){
    
    // Save the image in PPM format
    cv::imwrite(output_name, tgt);
    std::cout << "Image " << output_name << " saved successfully" << std::endl;
    if (tgt.empty()) {cout << "Saving an empty image as " << output_name << endl;}
    
}

void re_do_hw_1()
{

}

#define MAXLEN 256


#include "iptools/image/image.h"
#include "iptools/utility/utility.h"


int main(int argc, char** argv)
{

	image src_legacy, tgt_legacy;
	FILE *fp;
	char str[MAXLEN];
	char outfile[MAXLEN];
	size_t numberOfROI;
	char *pch;
	char *pch2;

    string src_name = argv[1];
    string tgt_name = argv[2];
    Mat src = imread(src_name, cv::IMREAD_GRAYSCALE);
    Mat src_color = imread(src_name);
    cv::Mat tgt = cv::Mat(src.size(), src.type());
    src.copyTo(tgt);


    char *function_name = argv[3];
    if (strncasecmp(function_name,"convert",MAXLEN)==0) {
        cout << "Converting the image from " << src_name << "to" << tgt_name << endl;
		convert_pgm(src_name, tgt_name);
    }
    else if (strncasecmp(function_name,"addG",MAXLEN)==0) {
        cout << "adding pixel value to gray scale image" << src_name <<endl;
        int pixel_value = atoi(argv[4]);
		add_Grey(src,tgt,pixel_value, tgt_name);
        save_image(tgt,tgt_name);
        
    }
    else if (strncasecmp(function_name,"binarizeG",MAXLEN)==0) {
        cout << "binarizing pixel values for " << src_name <<endl;
        int pixel_value = atoi(argv[4]);
		binarize_Grey(src,tgt,pixel_value);
        save_image(tgt,tgt_name);
        
    }
    else if (strncasecmp(function_name,"scaleG",MAXLEN)==0) {
        cout << "scaling image for " << src_name <<endl;
        float ratio = stof(argv[4]);

        cv::Mat resized_image((int)((float)src.cols * ratio),  (int)((float)src.cols * ratio), src.type());
		scale_Grey(src,resized_image,ratio);
        cout << "size of the target is " << resized_image.size() << endl;
        save_image(resized_image,tgt_name);
        
    }
        else if (strncasecmp(function_name,"re_do_hw1",MAXLEN)==0) {
        cout << "Using util functions from HW1 and Paramater.txt file " << src_name <<endl;


        if ((fp = fopen(argv[4],"r")) == NULL) {
            fprintf(stderr, "Can't open file: %s\n", argv[1]);
            exit(1);
        }

        while(fgets(str,MAXLEN,fp) != NULL) {
            printf("Parameters Detail: %s", str);


            //Input File String Token
            pch = strtok(str, " ");
            //printf("First Token: %s\n", pch);
            src_legacy.read(pch);

            //output file string token
            pch = strtok(NULL, " ");
            strcpy(outfile, pch);

            numberOfROI = atoi(strtok(NULL, " "));

            ROI roi;

            printf("Number of ROIs:%lu\n",numberOfROI);


            for (size_t i = 0; i < numberOfROI; i++)
            {

                printf("%lu\n\n",i);
                
                roi.x1 = atoi(strtok(NULL, " "));
                roi.y1 = atoi(strtok(NULL, " "));
                roi.Sx1 = atoi(strtok(NULL, " "));
                roi.Sy1 = atoi(strtok(NULL, " "));
                //function to call stringToken
                pch = strtok(NULL, " ");



                //troubleshoot end of string /n issue using
                //printf("PCF token: %s\n", pch);
                //printf("%i\n",strncasecmp(pch,"test",MAXLEN));
                // for (int i = 0; i < strlen(pch); i++) {
                // 	printf("Character at %d is %c and ASCII value is %d\n", i, pch[i], (int)pch[i]);
                // }


                if (strncasecmp(pch,"add",MAXLEN)==0) {
                    /* Add Intensity */
                    pch = strtok(NULL, " ");
                    utility::addGrey(src_legacy,tgt_legacy,atoi(pch),roi);
                    tgt_legacy.save(outfile);
                    src_legacy.read(outfile);

                }

                else if (strncasecmp(pch,"binarize",MAXLEN)==0) {
                    /* Thresholding */
                    pch = strtok(NULL, " ");
                    utility::binarize(src_legacy,tgt_legacy,atoi(pch),roi);
                    tgt_legacy.save(outfile);
                    src_legacy.read(outfile);


                }

                else if (strncasecmp(pch,"augmentGrey",MAXLEN)==0) {

                    image tgtR;
                    image tgt1p5;
                    image brigterTGT;

                    tgt_legacy = utility::cropROI(src_legacy, roi);
                    brigterTGT = tgt_legacy;

                    //scale factor
                    pch = strtok(NULL, " ");
                    tgt1p5 = utility::scale(tgt_legacy,atof(pch));

                    // bright qty
                    pch = strtok(NULL, " ");

                    //apply brightness to entire src_legacy image
                    ROI fullRoi;
                    fullRoi.x1=0;
                    fullRoi.y1=0;
                    fullRoi.Sx1 = brigterTGT.getNumberOfRows();
                    fullRoi.Sy1 = brigterTGT.getNumberOfColumns();
                    utility::addGrey(tgt_legacy,brigterTGT,atoi(pch),fullRoi);


                    std::string numStr = std::to_string(i); // convert integer to string

                    // Construct the base paths
                    std::string basePath = "hw1_q3a/" + numStr + "_original.pgm";
                    std::string basePath90 = "hw1_q3a/" + numStr + "_r90.pgm";
                    std::string basePath180 = "hw1_q3a/" + numStr + "_r180.pgm";
                    std::string basePath270 = "hw1_q3a/" + numStr + "_r270.pgm";

                    // Save images
                    tgt_legacy.save(basePath.c_str());
                    tgt_legacy = utility::rotateCCW90(tgt_legacy);
                    tgt_legacy.save(basePath90.c_str());
                    tgt_legacy = utility::rotateCCW90(tgt_legacy);
                    tgt_legacy.save(basePath180.c_str());
                    tgt_legacy = utility::rotateCCW90(tgt_legacy);
                    tgt_legacy.save(basePath270.c_str());

                    //scaled by x2
                    basePath = "hw1_q3b/" + numStr + "_originalScaled.pgm";
                    basePath90 = "hw1_q3b/" + numStr + "_r90.pgm";
                    basePath180 = "hw1_q3b/" + numStr + "_r180.pgm";
                    basePath270 = "hw1_q3b/" + numStr + "_r270.pgm";

                    
                    tgt1p5.save(basePath.c_str());
                    tgt1p5 = utility::rotateCCW90(tgt1p5);
                    tgt1p5.save(basePath90.c_str());
                    tgt1p5 = utility::rotateCCW90(tgt1p5);
                    tgt1p5.save(basePath180.c_str());
                    tgt1p5 = utility::rotateCCW90(tgt1p5);
                    tgt1p5.save(basePath270.c_str());

                    // brighter images
                    basePath = "hw1_q3c/" + numStr + "_originalBrighter.pgm";
                    basePath90 = "hw1_q3c/" + numStr + "_r90.pgm";
                    basePath180 = "hw1_q3c/" + numStr + "_r180.pgm";
                    basePath270 = "hw1_q3c/" + numStr + "_r270.pgm";

                    
                    brigterTGT.save(basePath.c_str());
                    brigterTGT = utility::rotateCCW90(brigterTGT);
                    brigterTGT.save(basePath90.c_str());
                    brigterTGT = utility::rotateCCW90(brigterTGT);
                    brigterTGT.save(basePath180.c_str());
                    brigterTGT = utility::rotateCCW90(brigterTGT);
                    brigterTGT.save(basePath270.c_str());
                }

                else if (strncasecmp(pch,"augmentColor",MAXLEN)==0) {

                    image roiImg;
                    image tgtMulColor;
                    image tgtAddColor;

                    roiImg = utility::cropROIColor(src_legacy, roi);

                    //multiplicative color brightness
                    pch = strtok(NULL, " ");
                    tgtMulColor = utility::mulColor(roiImg,1.9);

                    //additive color brightness
                    pch = strtok(NULL, " ");
                    tgtAddColor = utility::addColor(roiImg,atoi(pch));


                    std::string numStr = std::to_string(i); // convert integer to string

                    // Construct the base paths
                    std::string basePath = "hw1_q4a/" + numStr + "_original.ppm";
                    std::string basePath90 = "hw1_q4a/" + numStr + "_r90.ppm";
                    std::string basePath180 = "hw1_q4a/" + numStr + "_r180.ppm";
                    std::string basePath270 = "hw1_q4a/" + numStr + "_r270.ppm";

                    // Save images
                    roiImg.save(basePath.c_str());
                    roiImg = utility::rotateCCW90Color(roiImg);
                    roiImg.save(basePath90.c_str());
                    roiImg = utility::rotateCCW90Color(roiImg);
                    roiImg.save(basePath180.c_str());
                    roiImg = utility::rotateCCW90Color(roiImg);
                    roiImg.save(basePath270.c_str());

                    //scaled by x2
                    basePath = "hw1_q4b/" + numStr + "_originalMulColor.ppm";
                    basePath90 = "hw1_q4b/" + numStr + "_r90.ppm";
                    basePath180 = "hw1_q4b/" + numStr + "_r180.ppm";
                    basePath270 = "hw1_q4b/" + numStr + "_r270.ppm";

                    
                    tgtMulColor.save(basePath.c_str());
                    tgtMulColor = utility::rotateCCW90Color(tgtMulColor);
                    tgtMulColor.save(basePath90.c_str());
                    tgtMulColor = utility::rotateCCW90Color(tgtMulColor);
                    tgtMulColor.save(basePath180.c_str());
                    tgtMulColor = utility::rotateCCW90Color(tgtMulColor);
                    tgtMulColor.save(basePath270.c_str());

                    // brighter images
                    basePath = "hw1_q4c/" + numStr + "_originalAddColor.ppm";
                    basePath90 = "hw1_q4c/" + numStr + "_r90.ppm";
                    basePath180 = "hw1_q4c/" + numStr + "_r180.ppm";
                    basePath270 = "hw1_q4c/" + numStr + "_r270.ppm";

                    
                    tgtAddColor.save(basePath.c_str());
                    tgtAddColor = utility::rotateCCW90Color(tgtAddColor);
                    tgtAddColor.save(basePath90.c_str());
                    tgtAddColor = utility::rotateCCW90Color(tgtAddColor);
                    tgtAddColor.save(basePath180.c_str());
                    tgtAddColor = utility::rotateCCW90Color(tgtAddColor);
                    tgtAddColor.save(basePath270.c_str());

                }

                else if (strncasecmp(pch,"scale",MAXLEN)==0) {
                    /* Image scaling */
                    pch = strtok(NULL, " ");
                    utility::scale(src_legacy,atof(pch));
                    tgt_legacy.save(outfile);
                    src_legacy.read(outfile);

                }

                else if (strncasecmp(pch,"decreaseIntesity",MAXLEN)==0) {
                    /* Image scaling */
                    pch = strtok(NULL, " ");
                    pch2 = strtok(NULL, " ");
                    utility::decreaseIntesity(src_legacy,tgt_legacy,atoi(pch),atoi(pch2),roi);
                    tgt_legacy.save(outfile);
                    src_legacy.read(outfile);


                }

                else {
                    printf("No function: %s\n", pch);
                    continue;
                }
            

                //use modified picture as new src_legacy
            }
            


        }
        fclose(fp);
        return 0;
        
    }
    
    else{
        cout << "No such function" << function_name << endl;
    }
    
    return 0;
    
    
}
