/************************************************************
 *															*
 * This sample project include three functions:				*
 * 1. Add intensity for gray-level image.					*
 *    Input: source image, output image name, value			*
 *															*
 * 2. Image thresholding: pixels will become black if the	*
 *    intensity is below the threshold, and white if above	*
 *    or equal the threhold.								*
 *    Input: source image, output image name, threshold		*
 *															*
 * 3. Image scaling: reduction/expansion of 2 for 			*
 *    the width and length. This project uses averaging 	*
 *    technique for reduction and pixel replication			*
 *    technique for expansion.								*
 *    Input: source image, output image name, scale factor	*
 *															*
 ************************************************************/

#include "../iptools/core.h"
#include <strings.h>
#include <string.h>

using namespace std;

#define MAXLEN 256

int main (int argc, char** argv)
{
	image src, tgt;
	FILE *fp;
	char str[MAXLEN];
	char outfile[MAXLEN];
	size_t numberOfROI;
	char *pch;
	char *pch2;



	if ((fp = fopen(argv[1],"r")) == NULL) {
		fprintf(stderr, "Can't open file: %s\n", argv[1]);
		exit(1);
	}

	while(fgets(str,MAXLEN,fp) != NULL) {
		printf("Parameters Detail: %s", str);


		//Input File String Token
		pch = strtok(str, " ");
		//printf("First Token: %s\n", pch);
		src.read(pch);

		//output file string token
		pch = strtok(NULL, " ");
		strcpy(outfile, pch);

		numberOfROI = atoi(strtok(NULL, " "));

		ROI roi;

		printf("Number of ROIs:%lu\n",numberOfROI);


		for (size_t i = 0; i < numberOfROI; i++)
		{

			printf("%lu\n\n",i);
			
			roi.x1 = atoi(strtok(NULL, " "));
			roi.y1 = atoi(strtok(NULL, " "));
			roi.Sx1 = atoi(strtok(NULL, " "));
			roi.Sy1 = atoi(strtok(NULL, " "));
		    //function to call stringToken
			pch = strtok(NULL, " ");



			//troubleshoot end of string /n issue using
			//printf("PCF token: %s\n", pch);
			//printf("%i\n",strncasecmp(pch,"test",MAXLEN));
			// for (int i = 0; i < strlen(pch); i++) {
			// 	printf("Character at %d is %c and ASCII value is %d\n", i, pch[i], (int)pch[i]);
			// }


			if (strncasecmp(pch,"add",MAXLEN)==0) {
				/* Add Intensity */
				pch = strtok(NULL, " ");
				utility::addGrey(src,tgt,atoi(pch),roi);
				tgt.save(outfile);
				src.read(outfile);

			}

			else if (strncasecmp(pch,"binarize",MAXLEN)==0) {
				/* Thresholding */
				pch = strtok(NULL, " ");
				utility::binarize(src,tgt,atoi(pch),roi);
				tgt.save(outfile);
				src.read(outfile);


			}

			else if (strncasecmp(pch,"augmentGrey",MAXLEN)==0) {

				image tgtR;
				image tgt1p5;
				image brigterTGT;

				tgt = utility::cropROI(src, roi);
				brigterTGT = tgt;

				//scale factor
				pch = strtok(NULL, " ");
				tgt1p5 = utility::scale(tgt,atof(pch));

				// bright qty
				pch = strtok(NULL, " ");

				//apply brightness to entire src image
				ROI fullRoi;
				fullRoi.x1=0;
				fullRoi.y1=0;
				fullRoi.Sx1 = brigterTGT.getNumberOfRows();
				fullRoi.Sy1 = brigterTGT.getNumberOfColumns();
				utility::addGrey(tgt,brigterTGT,atoi(pch),fullRoi);


				std::string numStr = std::to_string(i); // convert integer to string

				// Construct the base paths
				std::string basePath = "hw1_q3a/" + numStr + "_original.pgm";
				std::string basePath90 = "hw1_q3a/" + numStr + "_r90.pgm";
				std::string basePath180 = "hw1_q3a/" + numStr + "_r180.pgm";
				std::string basePath270 = "hw1_q3a/" + numStr + "_r270.pgm";

				// Save images
				tgt.save(basePath.c_str());
				tgt = utility::rotateCCW90(tgt);
				tgt.save(basePath90.c_str());
				tgt = utility::rotateCCW90(tgt);
				tgt.save(basePath180.c_str());
				tgt = utility::rotateCCW90(tgt);
				tgt.save(basePath270.c_str());

				//scaled by x2
				basePath = "hw1_q3b/" + numStr + "_originalScaled.pgm";
				basePath90 = "hw1_q3b/" + numStr + "_r90.pgm";
				basePath180 = "hw1_q3b/" + numStr + "_r180.pgm";
				basePath270 = "hw1_q3b/" + numStr + "_r270.pgm";

				
				tgt1p5.save(basePath.c_str());
				tgt1p5 = utility::rotateCCW90(tgt1p5);
				tgt1p5.save(basePath90.c_str());
				tgt1p5 = utility::rotateCCW90(tgt1p5);
				tgt1p5.save(basePath180.c_str());
				tgt1p5 = utility::rotateCCW90(tgt1p5);
				tgt1p5.save(basePath270.c_str());

				// brighter images
				basePath = "hw1_q3c/" + numStr + "_originalBrighter.pgm";
				basePath90 = "hw1_q3c/" + numStr + "_r90.pgm";
				basePath180 = "hw1_q3c/" + numStr + "_r180.pgm";
				basePath270 = "hw1_q3c/" + numStr + "_r270.pgm";

				
				brigterTGT.save(basePath.c_str());
				brigterTGT = utility::rotateCCW90(brigterTGT);
				brigterTGT.save(basePath90.c_str());
				brigterTGT = utility::rotateCCW90(brigterTGT);
				brigterTGT.save(basePath180.c_str());
				brigterTGT = utility::rotateCCW90(brigterTGT);
				brigterTGT.save(basePath270.c_str());
			}

			else if (strncasecmp(pch,"augmentColor",MAXLEN)==0) {

				image roiImg;
				image tgtMulColor;
				image tgtAddColor;

				roiImg = utility::cropROIColor(src, roi);

				//multiplicative color brightness
				pch = strtok(NULL, " ");
				tgtMulColor = utility::mulColor(roiImg,1.9);

				//additive color brightness
				pch = strtok(NULL, " ");
				tgtAddColor = utility::addColor(roiImg,atoi(pch));


				std::string numStr = std::to_string(i); // convert integer to string

				// Construct the base paths
				std::string basePath = "hw1_q4a/" + numStr + "_original.ppm";
				std::string basePath90 = "hw1_q4a/" + numStr + "_r90.ppm";
				std::string basePath180 = "hw1_q4a/" + numStr + "_r180.ppm";
				std::string basePath270 = "hw1_q4a/" + numStr + "_r270.ppm";

				// Save images
				roiImg.save(basePath.c_str());
				roiImg = utility::rotateCCW90Color(roiImg);
				roiImg.save(basePath90.c_str());
				roiImg = utility::rotateCCW90Color(roiImg);
				roiImg.save(basePath180.c_str());
				roiImg = utility::rotateCCW90Color(roiImg);
				roiImg.save(basePath270.c_str());

				//scaled by x2
				basePath = "hw1_q4b/" + numStr + "_originalMulColor.ppm";
				basePath90 = "hw1_q4b/" + numStr + "_r90.ppm";
				basePath180 = "hw1_q4b/" + numStr + "_r180.ppm";
				basePath270 = "hw1_q4b/" + numStr + "_r270.ppm";

				
				tgtMulColor.save(basePath.c_str());
				tgtMulColor = utility::rotateCCW90Color(tgtMulColor);
				tgtMulColor.save(basePath90.c_str());
				tgtMulColor = utility::rotateCCW90Color(tgtMulColor);
				tgtMulColor.save(basePath180.c_str());
				tgtMulColor = utility::rotateCCW90Color(tgtMulColor);
				tgtMulColor.save(basePath270.c_str());

				// brighter images
				basePath = "hw1_q4c/" + numStr + "_originalAddColor.ppm";
				basePath90 = "hw1_q4c/" + numStr + "_r90.ppm";
				basePath180 = "hw1_q4c/" + numStr + "_r180.ppm";
				basePath270 = "hw1_q4c/" + numStr + "_r270.ppm";

				
				tgtAddColor.save(basePath.c_str());
				tgtAddColor = utility::rotateCCW90Color(tgtAddColor);
				tgtAddColor.save(basePath90.c_str());
				tgtAddColor = utility::rotateCCW90Color(tgtAddColor);
				tgtAddColor.save(basePath180.c_str());
				tgtAddColor = utility::rotateCCW90Color(tgtAddColor);
				tgtAddColor.save(basePath270.c_str());

			}

			else if (strncasecmp(pch,"scale",MAXLEN)==0) {
				/* Image scaling */
				pch = strtok(NULL, " ");
				utility::scale(src,atof(pch));
				tgt.save(outfile);
				src.read(outfile);

			}

			else if (strncasecmp(pch,"decreaseIntesity",MAXLEN)==0) {
				/* Image scaling */
				pch = strtok(NULL, " ");
				pch2 = strtok(NULL, " ");
				utility::decreaseIntesity(src,tgt,atoi(pch),atoi(pch2),roi);
				tgt.save(outfile);
				src.read(outfile);


			}

			else {
				printf("No function: %s\n", pch);
				continue;
			}
		

			//use modified picture as new src
		}
		


	}
	fclose(fp);
	return 0;
}

